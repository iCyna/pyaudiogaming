/*
	BASSenc_OPUS 2.4 Java class
	Copyright (c) 2016-2020 Un4seen Developments Ltd.

	See the BASSENC_OPUS.CHM file for more detailed documentation
*/

package com.un4seen.bass;

@SuppressWarnings({"all"})
public class BASSenc_OPUS
{
	// BASS_Encode_OPUS_NewStream flags
	public static final int BASS_ENCODE_OPUS_RESET = 0x1000000;
	public static final int BASS_ENCODE_OPUS_CTLONLY = 0x2000000;

	public static native int BASS_Encode_OPUS_GetVersion();

	public static native int BASS_Encode_OPUS_Start(int handle, String options, int flags, BASSenc.ENCODEPROC proc, Object user);
	public static native int BASS_Encode_OPUS_StartFile(int handle, String options, int flags, String filename);
	public static native boolean BASS_Encode_OPUS_NewStream(int handle, String options, int flags);

	static {
		System.loadLibrary("bassenc");
		System.loadLibrary("bassenc_opus");
	}
}
