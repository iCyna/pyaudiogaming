/*
	BASSloud 2.4 Java class
	Copyright (c) 2024 Un4seen Developments Ltd.

	See the BASSLOUD.CHM file for more detailed documentation
*/

package com.un4seen.bass;

@SuppressWarnings({"all"})
public class BASSloud
{
	// BASS_Loudness_Start flags / BASS_Loudness_GetLevel modes
	public static final int BASS_LOUDNESS_CURRENT = 0;
	public static final int BASS_LOUDNESS_INTEGRATED = 1;
	public static final int BASS_LOUDNESS_RANGE = 2;
	public static final int BASS_LOUDNESS_PEAK = 4;
	public static final int BASS_LOUDNESS_TRUEPEAK = 8;
	public static final int BASS_LOUDNESS_AUTOFREE = 0x8000;

	public static native int BASS_Loudness_GetVersion();

	public static native int BASS_Loudness_Start(int handle, int flags, int priority);
	public static native boolean BASS_Loudness_Stop(int handle);
	public static native boolean BASS_Loudness_SetChannel(int handle, int channel, int priority);
	public static native int BASS_Loudness_GetChannel(int handle);
	public static native boolean BASS_Loudness_GetLevel(int handle, int mode, BASS.FloatValue level);
	public static native boolean BASS_Loudness_GetLevelMulti(int[] handles, int count, int mode, BASS.FloatValue level);

	static {
		System.loadLibrary("bassloud");
	}
}
