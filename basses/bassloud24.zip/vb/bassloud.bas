Attribute VB_Name = "BASSloud"
' BASSloud 2.4 Visual Basic module
' Copyright (c) 2023 Un4seen Developments Ltd.
'
' See the BASSLOUD.CHM file for more detailed documentation

' BASS_Loudness_Start flags / BASS_Loudness_GetLevel modes
Global Const BASS_LOUDNESS_CURRENT = 0
Global Const BASS_LOUDNESS_INTEGRATED = 1
Global Const BASS_LOUDNESS_RANGE = 2
Global Const BASS_LOUDNESS_PEAK = 4
Global Const BASS_LOUDNESS_TRUEPEAK = 8
Global Const BASS_LOUDNESS_AUTOFREE = &H8000

Declare Function BASS_Loudness_GetVersion Lib "bassloud.dll" () As Long

Declare Function BASS_Loudness_Start Lib "bassloud.dll" (ByVal handle As Long, ByVal flags As Long, ByVal priority As Long) As Long
Declare Function BASS_Loudness_Stop Lib "bassloud.dll" (ByVal handle As Long) As Long
Declare Function BASS_Loudness_SetChannel Lib "bassloud.dll" (ByVal handle As Long, ByVal channel As Long) As Long
Declare Function BASS_Loudness_GetChannel Lib "bassloud.dll" (ByVal handle As Long) As Long
Declare Function BASS_Loudness_GetLevel Lib "bassloud.dll" (ByVal handle As Long, ByVal mode As Long, ByRef level As Single) As Long
Declare Function BASS_Loudness_GetLevelMulti Lib "bassloud.dll" (ByRef handles As Long, ByVal count As Long, ByVal mode As Long, ByRef level As Single) As Long
