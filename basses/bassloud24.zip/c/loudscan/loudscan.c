/*
	BASSloud scanner
	Copyright (c) 2023 Un4seen Developments Ltd.
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "bass.h"
#include "bassloud.h"

#ifdef _WIN32 // Windows
#include <malloc.h>
#else // OSX
#include <string.h>
#include <glob.h>
#endif

// display error messages
void Error(const char *text)
{
	printf("Error(%d): %s\n", BASS_ErrorGetCode(), text);
	BASS_Free();
	exit(0);
}

int main(int argc, char **argv)
{
	DWORD decoder;
	HLOUDNESS *loudness;
	float level;
	int a;

	printf("BASSloud scanner\n"
			"----------------\n");

	// check the correct BASS was loaded
	if (HIWORD(BASS_GetVersion()) != BASSVERSION) {
		printf("An incorrect version of BASS was loaded");
		return 0;
	}

	if (argc < 2) {
		printf("\tusage: loudscan <files>\n");
		return 0;
	}

	// initalize "no sound" device
	if (!BASS_Init(0, 44100, 0, 0, NULL))
		Error("Can't initialize device");

	{ // load plugins for additional input format support
		const char *basspath = BASS_GetConfigPtr(BASS_CONFIG_FILENAME);
		if (basspath) {
#ifdef _WIN32
			WIN32_FIND_DATA fd;
			HANDLE fh;
			int pathlen = strrchr(basspath, '\\') + 1 - basspath;
			char *pattern = alloca(pathlen + 10);
			sprintf(pattern, "%.*sbass*.dll", pathlen, basspath);
			fh = FindFirstFile(pattern, &fd);
			if (fh != INVALID_HANDLE_VALUE) {
				int c = 0;
				do {
					if (BASS_PluginLoad(fd.cFileName, 0)) {
						if (!c++) printf("plugins:");
						printf(" %s", fd.cFileName);
					}
				} while (FindNextFile(fh, &fd));
				if (c) printf("\n");
				FindClose(fh);
			}
#else
			glob_t g;
			int pathlen = strrchr(basspath, '/') + 1 - basspath;
#ifdef __APPLE__
			char *pattern = alloca(pathlen + 16);
			sprintf(pattern, "%.*slibbass?*.dylib", pathlen, basspath);
#else
			char *pattern = alloca(pathlen + 13);
			sprintf(pattern, "%.*slibbass?*.so", pathlen, basspath);
#endif
			if (!glob(pattern, 0, 0, &g)) {
				int a, c = 0;
				for (a = 0; a < g.gl_pathc; a++) {
					if (BASS_PluginLoad(g.gl_pathv[a], 0)) {
						if (!c++) printf("plugins:");
						printf(" %s", strrchr(g.gl_pathv[a], '/') + 1);
					}
				}
				if (c) printf("\n");
			}
			globfree(&g);
#endif
		}
	}

	loudness = malloc((argc - 1) * sizeof(HLOUDNESS));

	printf("            loudness  range   peak  tpeak\n");
	for (a = 0; a < argc - 1; a++) {
		printf("%s:\n", argv[1 + a]);
		// create decoder for file
		decoder = BASS_StreamCreateFile(0, argv[1 + a], 0, 0, BASS_STREAM_DECODE | BASS_SAMPLE_FLOAT);
		if (!decoder && BASS_ErrorGetCode() == BASS_ERROR_FILEFORM) {
			decoder = BASS_MusicLoad(FALSE, argv[1 + a], 0, 0, BASS_MUSIC_DECODE | BASS_SAMPLE_FLOAT, 0);
			if (decoder) BASS_ChannelSetPosition(decoder, BASS_ChannelSeconds2Bytes(decoder, 600), BASS_POS_END); // limit it to 10 mins in case it's never-ending
		}
		if (!decoder) Error("Can't handle the file");
		// start loudness, loudness range, peak, and true peak measurement
		loudness[a] = BASS_Loudness_Start(decoder, BASS_LOUDNESS_INTEGRATED | BASS_LOUDNESS_RANGE | BASS_LOUDNESS_PEAK | BASS_LOUDNESS_TRUEPEAK, 0);
		if (!loudness[a]) Error("Can't start loudness measurement");
		// process the entire file
		printf("processing...");
		while (1) {
			float buf[10000];
			int c = BASS_ChannelGetData(decoder, buf, sizeof(buf));
			if (c < 0) break;
		}
		// free the decoder
		BASS_ChannelFree(decoder);
		// display the measured levels
		BASS_Loudness_GetLevel(loudness[a], BASS_LOUDNESS_INTEGRATED, &level);
		if (level == -HUGE_VAL) // no loudness level available (too short or silent)
			printf("\r%20s%7s", "n/a", "n/a");
		else {
			printf("\r%20.2f", level);
			BASS_Loudness_GetLevel(loudness[a], BASS_LOUDNESS_RANGE, &level);
			printf("%7.2f", level);
		}
		BASS_Loudness_GetLevel(loudness[a], BASS_LOUDNESS_PEAK, &level);
		printf("%7.3f", level);
		BASS_Loudness_GetLevel(loudness[a], BASS_LOUDNESS_TRUEPEAK, &level);
		printf("%7.3f\n", level);
	}
	// display combined levels if more than 1
	if (argc > 2) {
		printf("-----------------------------------------\n");
		BASS_Loudness_GetLevelMulti(loudness, argc - 1, BASS_LOUDNESS_INTEGRATED, &level);
		if (level == -HUGE_VAL) // no loudness level available (too short or silent)
			printf("\r%20s%7s", "n/a", "n/a");
		else {
			printf("%20.2f", level);
			BASS_Loudness_GetLevelMulti(loudness, argc - 1, BASS_LOUDNESS_RANGE, &level);
			printf("%7.2f", level);
		}
		BASS_Loudness_GetLevelMulti(loudness, argc - 1, BASS_LOUDNESS_PEAK, &level);
		printf("%7.3f", level);
		BASS_Loudness_GetLevelMulti(loudness, argc - 1, BASS_LOUDNESS_TRUEPEAK, &level);
		printf("%7.3f\n", level);
	}

	// free the loudness measurements
	for (a = 0; a < argc - 1; a++)
		BASS_Loudness_Stop(loudness[a]);
	free(loudness);

	BASS_Free();
	return 0;
}
